# PrintUtility Installation steps
1. Download & extract the printutility-Installer zip file.
2. Navigate to PrintUtility-installer-PrintUtility_master > ValidationPrintUtility > Debug > ValidationPrintUtility.msi
3. Run the installer.
4. Once installed, navigate to C:\Program Files (x86)\Zogato\ValidationPrintUtility.
5. Open the PrintUtility.exe.config file & replace the existing IP with the server IP.
6. Save and exit the file.
7. Run the PrintUtility.exe
